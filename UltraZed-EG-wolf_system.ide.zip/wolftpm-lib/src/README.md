# wolfTPM Library for Xilinx SDK

User provides `TPM2_IoCb` for hardware interface. Example Xilinx code found in tpm_io.c with `__XILINX__`.
