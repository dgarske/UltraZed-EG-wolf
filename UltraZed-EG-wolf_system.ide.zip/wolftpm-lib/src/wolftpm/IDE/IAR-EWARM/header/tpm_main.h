#ifndef _TPM_MAIN_H_
#define _TPM_MAIN_H_


int TPM2_Cust_Example(void* userCtx);


#endif /* _TPM_MAIN_H_ */
