# Intel QuickAssist Adapter Asynchronous Support

Please contact wolfSSL at info@wolfssl.com to request an evaluation.
