See caam_doc.pdf for documentation about building and using.
