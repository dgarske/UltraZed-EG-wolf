## Pre-compiled Key management tools for windows (64bit)

Full sources available in the [keytools](../../../tools/keytools) directory in this repository.
